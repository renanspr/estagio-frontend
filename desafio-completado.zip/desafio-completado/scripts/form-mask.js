$(document).ready(function (){
    $("#phone").mask("(99) 99999-9999");
})